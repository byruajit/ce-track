# The NovaBot autopsy: my findings

One row per finding, written right after the step that shows it (see `README.md`).

- **Component:** exactly one of `system` · `user_input` · `history` · `knowledge` · `tools` · `memory_state` · `budget`.
- **Evidence:** a line copied from your script's output, in "double quotes" (or `backticks` for code and payloads).
- **What is missing in the design:** the rule or limit that should have existed. Never "the model was wrong".

| # | Component | Evidence (quoted from the window) | What is missing in the design |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

Row 1 after step 2 · row 2 after step 3 · row 3 after step 4 · row 4 after step 5 · row 5 after step 6.
Add more rows if you find more.

## Top three and fix first (after step 6, with your pod)

1.
2.
3.

**Fix first:** (finding #, component, and why it changes the answer most)
